# scrappy
Simple project to play with selenium and some scrapying.
